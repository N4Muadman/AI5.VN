@extends('layout')
@section('title', $news?->first()?->category?->name) <!-- SEO: dynamic title -->

@section('content')
    <div id="ai-news" class="content-section active">
        <div class="section-header">
            <h1>📰 {{ $news?->first()?->category?->name }}</h1>
            {{-- <p>Tin tức về AI, Machine Learning, Deep Learning, Generative AI</p> --}}
        </div>
        <div class="section-content">
            <div class="card-grid">
                @forelse ($news as $it)
                    <div class="card">
                        <h2><a href="{{route('news.detail', $it->id)}}">{{$it->title}}</a></h2>
                        <p>{{$it->description}}</p>
                        <div class="card-meta">📅 {{$it->created_at->format('Y-m-d')}} | ⏱️ 10 phút đọc</div>
                    </div>
                @empty
                    <p class="text-center">Chưa có tin tức nào</p>
                @endforelse
            </div>
        </div>
    </div>
@endsection
