<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\BannerController;
use App\Http\Controllers\NewsController;
use App\Http\Controllers\PagesController;
use Illuminate\Support\Facades\Route;

Route::get('/', [PagesController::class, 'home'])->name('home');

Route::get('blogs', [PagesController::class, 'news'])->name('news');
Route::get('blogs/{id}', [PagesController::class, 'news'])->name('news.category');
Route::get('blogs/detail/{id}', [PagesController::class, 'newsDetail'])->name('news.detail');

Route::get('login', [AuthController::class, 'showLoginForm'])->name('login.form');
Route::post('auth-login', [AuthController::class, 'login'])->name('login');
Route::get('logout', [AuthController::class, 'logout'])->name('logout');

Route::middleware('is_admin')->prefix('admin')->group(function () {
    Route::get('/', function () {
        return redirect()->route('banners.index');
    })->name('admin.home');
    Route::post('/upload-image', [NewsController::class, 'uploadImage'])->name('upload.image');
    Route::resource('banners', BannerController::class)->names('banners');
});
