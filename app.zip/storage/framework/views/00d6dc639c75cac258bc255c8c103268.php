<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="https://cdn.ckeditor.com/ckeditor5/46.0.0/ckeditor5.css">
    <style>
        /* Tùy chỉnh chiều cao của editor */
        .ck-editor__editable {
            min-height: 400px !important;
            max-height: 800px !important;
        }

        /* Hoặc có thể set chiều cao cố định */
        .ck-editor__editable_inline {
            height: 500px !important;
        }

        /* Tùy chỉnh toolbar */
        .ck-toolbar {
            border-bottom: 1px solid #c4c4c4 !important;
            padding: 10px !important;
        }

        /* Tùy chỉnh font cho editor */
        .ck-content {
            font-family: 'Arial', sans-serif;
            font-size: 14px;
            line-height: 1.6;
        }

        /* Tùy chỉnh dropdown menu */
        .ck-dropdown__panel {
            max-height: 300px !important;
            overflow-y: auto !important;
        }

        /* Responsive toolbar */
        @media (max-width: 768px) {
            .ck-toolbar {
                flex-wrap: wrap !important;
            }

            .ck-editor__editable {
                min-height: 300px !important;
            }
        }

        /* Tùy chỉnh focus state */
        .ck-editor__editable:focus {
            border-color: #007bff !important;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25) !important;
        }

        /* Tùy chỉnh placeholder */
        .ck-editor__editable.ck-placeholder::before {
            color: #999 !important;
            font-style: italic !important;
        }

    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        </li>
                        <li class="breadcrumb-item" aria-current="page">Quản lý tin tức</li>
                    </ul>
                </div>
                <div class="col-md-12">
                    <div class="page-header-title">
                        <h2 class="mb-2">Danh sách tin tức</h2>
                        <button data-bs-toggle="modal" data-bs-target="#add-news"
                            class="btn btn-light-primary d-flex align-items-center gap-2"><i class="ti ti-plus"></i> Thêm
                            tin tức</button>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <form action="<?php echo e(route('news.index')); ?>" method="get">
        <div class="row align-items-center mb-3">
            <div class="col-12 col-md-3">
                <input type="text" class="form-control" name="title" placeholder="Tìm kiếm theo tiêu đề"
                    value="<?php echo e(request('title')); ?>">
            </div>

            <div class="col-3">
                <button type="submit" class="btn btn-info">Tìm kiếm</button>
            </div>
        </div>
    </form>
    <div class="row">
        <div class="col-12">
            <div class="card table-card">
                <div class="card-body pt-3">
                    <div class="table-responsive">
                        <table class="table table-hover text-center table-fixed" id="pc-dt-simple">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Tiêu đề</th>
                                    <th>Danh mục</th>
                                    <th>Ảnh</th>
                                    <th>Mô tả ngắn</th>
                                    <th>Chức năng</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($it->id); ?></td>
                                        <td><?php echo e($it->title); ?></td>
                                        <td><?php echo e($it->category?->name); ?></td>
                                        <td><img src="<?php echo e($it->image); ?>" width="60px" alt=""></td>
                                        <td><?php echo e($it->description); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('news.detail', $it->id)); ?>"
                                                class="avtar avtar-details avtar-xs btn-link-secondary"
                                                title="XEM CHI TIẾT">
                                                <i class="ti ti-eye f-20"></i>
                                            </a>
                                            <a href="#"class="avtar avtar-edit avtar-xs btn-link-secondary"
                                                data-id="<?php echo e($it->id); ?>" title="CẬP NHẬT">
                                                <i class="ti ti-edit f-20"></i>
                                            </a>
                                            <a href="#" class="avtar avtar-delete avtar-xs btn-link-secondary"
                                                data-title="<?php echo e($it->title); ?>" data-id="<?php echo e($it->id); ?>"
                                                title="XÓA tin tức">
                                                <i class="ti ti-trash f-20"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5">
                                            <p class="text-center">Không có tin tức nào</p>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <div class="ps-5 pe-5">
                            <?php echo e($news->links('pagination::bootstrap-5')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Thêm tin tức -->
    <div class="modal fade" id="add-news" tabindex="-1" aria-labelledby="addNewsModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addNewsModalLabel">Thêm mới tin tức</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                                <div class="card-body">
                                    <form id="add-news-form" action="<?php echo e(route('news.store')); ?>" method="post"
                                        enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="row g-3">
                                            <div class="col-12">
                                                <div class="mb-3 mb-0">
                                                    <label class="form-label">Tiêu đề</label>
                                                    <input type="text" class="form-control" name="title"
                                                        placeholder="Tiều đề tin tức" required>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="mb-3 mb-0">
                                                    <label class="form-label">Danh mục sản phẩm</label>
                                                    <select name="category_id" class="form-select">
                                                        <option value="">Chọn danh mục</option>
                                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-xl-12">
                                                <div class="section-card">
                                                    <div class="section-title">
                                                        <i class="fas fa-images"></i>
                                                        Hình ảnh bài viết
                                                    </div>
                                                    <div class="upload-area" id="upload-area">
                                                        <i class="fas fa-cloud-upload-alt fa-3x text-muted mb-3"></i>
                                                        <h5>Kéo thả ảnh vào đây hoặc click để chọn</h5>
                                                        <p class="text-muted">Hỗ trợ nhiều ảnh, định dạng: JPG, PNG, GIF
                                                        </p>
                                                        <input type="file" id="file-upload" name="image"
                                                            accept="image/*" style="display: none;">
                                                        <button type="button" class="custom-file-upload">
                                                            <i class="fas fa-plus me-2"></i>Chọn ảnh
                                                        </button>
                                                    </div>
                                                    <div class="d-flex flex-wrap mt-3" id="image-preview-container">
                                                        <!-- Preview images will be inserted here -->
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="mb-3 mb-0"><label class="form-label">Nội dung ngắn</label>
                                                    <textarea class="form-control" name="description" rows="3" placeholder="Nội dung ngắn" required></textarea>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="mb-3 mb-0"><label class="form-label">Nội dung chính</label>
                                                    <textarea class="form-control content" name="content" id="content" rows="3" placeholder="Nội dung chính"></textarea>
                                                </div>
                                            </div>

                                            <div class="col-12">
                                                <div class="row align-items-end justify-content-end g-3">
                                                    <div class="col-sm-auto btn-page">
                                                        <button type="submit" class="btn btn-primary">Thêm mới</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Sửa tin tức -->
    <div class="modal fade" id="edit-news" tabindex="-1" aria-labelledby="editNewsModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editNewsModalLabel">Cập nhật tin tức</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                                <div class="card-body">
                                    <form id="edit-news-form" method="post" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class="row g-3">
                                            <div class="col-12">
                                                <div class="mb-3 mb-0">
                                                    <label class="form-label">Tiêu đề</label>
                                                    <input type="text" class="form-control" name="title"
                                                        id="edit-title" placeholder="Tiều đề tin tức" required>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="mb-3 mb-0">
                                                    <label class="form-label">Danh mục sản phẩm</label>
                                                    <select name="category_id" id="edit-category" class="form-select">
                                                        <option value="">Chọn danh mục</option>
                                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-xl-12">
                                                <div class="section-card">
                                                    <div class="section-title">
                                                        <i class="fas fa-images"></i>
                                                        Hình ảnh bài viết
                                                    </div>
                                                    <div class="upload-area" id="edit-upload-area">
                                                        <i class="fas fa-cloud-upload-alt fa-3x text-muted mb-3"></i>
                                                        <h5>Kéo thả ảnh vào đây hoặc click để chọn</h5>
                                                        <p class="text-muted">Hỗ trợ nhiều ảnh, định dạng: JPG, PNG, GIF
                                                        </p>
                                                        <input type="file" id="edit-file-upload" name="image"
                                                            accept="image/*" style="display: none;">
                                                        <button type="button" class="custom-file-upload"
                                                            id="edit-file-btn">
                                                            <i class="fas fa-plus me-2"></i>Chọn ảnh
                                                        </button>
                                                    </div>
                                                    <div class="d-flex flex-wrap mt-3" id="edit-image-preview-container">
                                                        <!-- Preview images will be inserted here -->
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="mb-3 mb-0"><label class="form-label">Nội dung ngắn</label>
                                                    <textarea class="form-control" name="description" id="edit-description" rows="3" placeholder="Nội dung ngắn"
                                                        required></textarea>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="mb-3 mb-0"><label class="form-label">Nội dung chính</label>
                                                    <textarea class="form-control content" name="content" id="edit-content" rows="3"
                                                        placeholder="Nội dung chính"></textarea>
                                                </div>
                                            </div>

                                            <div class="col-12">
                                                <div class="row align-items-end justify-content-end g-3">
                                                    <div class="col-sm-auto btn-page">
                                                        <button type="submit" class="btn btn-primary">Cập nhật</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Xác nhận xóa -->
    <div class="modal fade" id="delete-news" tabindex="-1" aria-labelledby="deleteNewsModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteNewsModalLabel">Xác nhận xóa</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Bạn có chắc chắn muốn xóa tin tức "<span id="delete-news-title"></span>" không?</p>
                    <p class="text-danger"><small>Hành động này không thể hoàn tác!</small></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                    <form id="delete-news-form" method="post" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Xóa</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.ckeditor.com/ckeditor5/46.0.0/ckeditor5.umd.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        let addContentEditor, editContentEditor;

        // Destructure các plugins từ CKEDITOR
        const {
            ClassicEditor,
            Essentials,
            Bold,
            Italic,
            Underline,
            Strikethrough,
            Subscript,
            Superscript,
            Font,
            FontSize,
            FontFamily,
            FontColor,
            FontBackgroundColor,
            Paragraph,
            Heading,
            List,
            TodoList,
            Link,
            Image,
            ImageCaption,
            ImageStyle,
            ImageToolbar,
            ImageUpload,
            Table,
            TableToolbar,
            MediaEmbed,
            BlockQuote,
            HorizontalLine,
            Alignment,
            Indent,
            IndentBlock,
            SpecialCharacters,
            Undo,
            FindAndReplace,
            SelectAll,
            SourceEditing,
            Base64UploadAdapter
        } = CKEDITOR;

        // Cấu hình editor đầy đủ
        const editorConfig = {
            licenseKey: 'eyJhbGciOiJFUzI1NiJ9.eyJleHAiOjE3ODA1MzExOTksImp0aSI6ImM0MGE2YjEzLWZmODEtNGJmMC1iOGYwLWQ1MWI4NzA5NzVjMyIsInVzYWdlRW5kcG9pbnQiOiJodHRwczovL3Byb3h5LWV2ZW50LmNrZWRpdG9yLmNvbSIsImRpc3RyaWJ1dGlvbkNoYW5uZWwiOlsiY2xvdWQiLCJkcnVwYWwiXSwiZmVhdHVyZXMiOlsiRFJVUCIsIkUyUCIsIkUyVyJdLCJ2YyI6IjE1Y2NjZGExIn0.KelA2dTdceQy88aTU2WVfxT1dfAI2Sz8jlGbxZkvlPTNycaxj6Ydnpj6Xl2YT9jK3CfFnskQmD-cjCJZj9QWEA', // Sử dụng GPL license miễn phí
            plugins: [
                Essentials,
                Bold,
                Italic,
                Underline,
                Strikethrough,
                Subscript,
                Superscript,
                Font,
                FontSize,
                FontFamily,
                FontColor,
                FontBackgroundColor,
                Paragraph,
                Heading,
                List,
                TodoList,
                Link,
                Image,
                ImageCaption,
                ImageStyle,
                ImageToolbar,
                ImageUpload,
                Table,
                TableToolbar,
                MediaEmbed,
                BlockQuote,
                HorizontalLine,
                Alignment,
                Indent,
                IndentBlock,
                SpecialCharacters,
                Undo,
                FindAndReplace,
                SelectAll,
                SourceEditing,
                Base64UploadAdapter
            ],
            toolbar: {
                items: [
                    'heading', '|',
                    'fontSize', 'fontFamily', '|',
                    'fontColor', 'fontBackgroundColor', '|',
                    'bold', 'italic', 'underline', 'strikethrough', '|',
                    'subscript', 'superscript', '|',
                    'alignment', '|',
                    'indent', 'outdent', '|',
                    'bulletedList', 'numberedList', 'todoList', '|',
                    'link', 'uploadImage', 'insertTable', '|',
                    'mediaEmbed', 'blockQuote', 'horizontalLine', '|',
                    'specialCharacters', '|',
                    'undo', 'redo', '|',
                    'findAndReplace', 'selectAll', '|',
                    'sourceEditing'
                ],
                shouldNotGroupWhenFull: false
            },
            heading: {
                options: [{
                        model: 'paragraph',
                        title: 'Paragraph',
                        class: 'ck-heading_paragraph'
                    },
                    {
                        model: 'heading1',
                        view: 'h1',
                        title: 'Heading 1',
                        class: 'ck-heading_heading1'
                    },
                    {
                        model: 'heading2',
                        view: 'h2',
                        title: 'Heading 2',
                        class: 'ck-heading_heading2'
                    },
                    {
                        model: 'heading3',
                        view: 'h3',
                        title: 'Heading 3',
                        class: 'ck-heading_heading3'
                    },
                    {
                        model: 'heading4',
                        view: 'h4',
                        title: 'Heading 4',
                        class: 'ck-heading_heading4'
                    }
                ]
            },
            fontSize: {
                options: [9, 10, 11, 12, 'default', 14, 16, 18, 20, 22, 24, 26, 28, 36, 48, 72]
            },
            fontFamily: {
                options: [
                    'default',
                    'Arial, Helvetica, sans-serif',
                    'Courier New, Courier, monospace',
                    'Georgia, serif',
                    'Lucida Sans Unicode, Lucida Grande, sans-serif',
                    'Tahoma, Geneva, sans-serif',
                    'Times New Roman, Times, serif',
                    'Trebuchet MS, Helvetica, sans-serif',
                    'Verdana, Geneva, sans-serif'
                ]
            },
            alignment: {
                options: ['left', 'right', 'center', 'justify']
            },
            image: {
                toolbar: [
                    'imageTextAlternative',
                    'imageStyle:inline',
                    'imageStyle:block',
                    'imageStyle:side',
                    'linkImage',
                    'imageStyle:alignLeft',
                    'imageStyle:alignCenter',
                    'imageStyle:alignRight'
                ],
                styles: ['full', 'side', 'alignLeft', 'alignCenter', 'alignRight']
            },
            table: {
                contentToolbar: [
                    'tableColumn',
                    'tableRow',
                    'mergeTableCells',
                    'tableCellProperties',
                    'tableProperties'
                ]
            },
            list: {
                properties: {
                    styles: true,
                    startIndex: true,
                    reversed: true
                }
            },
            link: {
                decorators: {
                    addTargetToExternalLinks: true,
                    defaultProtocol: 'https://'
                }
            }
        };

        document.addEventListener('DOMContentLoaded', function() {
            // Tạo wrapper container
            const contentElement = document.querySelector('#content');
            if (contentElement) {
                const wrapper = document.createElement('div');
                wrapper.className = 'ckeditor-container';
                contentElement.parentElement.insertBefore(wrapper, contentElement);
                wrapper.appendChild(contentElement);

                ClassicEditor
                    .create(contentElement, editorConfig)
                    .then(editor => {
                        addContentEditor = editor;

                        // Set minimum height
                        const editable = editor.ui.getEditableElement();
                        editable.style.minHeight = '400px';

                        console.log('CKEditor 5 initialized successfully');
                        console.log('Available plugins:', editor.plugins.get('Essentials'));
                    })
                    .catch(error => {
                        console.error('CKEditor 5 initialization failed:', error);
                    });
            }
        });

        function initEditEditor() {
            return new Promise((resolve, reject) => {
                const editContentElement = document.querySelector('#edit-content');
                if (editContentElement) {
                    const wrapper = document.createElement('div');
                    wrapper.className = 'ckeditor-container';
                    editContentElement.parentElement.insertBefore(wrapper, editContentElement);
                    wrapper.appendChild(editContentElement);

                    ClassicEditor
                        .create(editContentElement, editorConfig)
                        .then(editor => {
                            editContentEditor = editor;

                            // Set minimum height
                            const editable = editor.ui.getEditableElement();
                            editable.style.minHeight = '400px';

                            resolve(editor);
                        })
                        .catch(error => {
                            console.error('Edit CKEditor 5 failed:', error);
                            reject(error);
                        });
                }
            });
        }

        // Các function khác giữ nguyên
        function initImageUpload(uploadAreaId, fileUploadId, previewContainerId, buttonId) {
            const uploadArea = document.getElementById(uploadAreaId);
            const fileUpload = document.getElementById(fileUploadId);
            const previewContainer = document.getElementById(previewContainerId);
            const uploadButton = buttonId ? document.getElementById(buttonId) : uploadArea?.querySelector(
                '.custom-file-upload');

            if (!uploadArea || !fileUpload || !previewContainer) return;

            uploadArea.addEventListener('click', () => fileUpload.click());
            if (uploadButton) {
                uploadButton.addEventListener('click', (e) => {
                    e.stopPropagation();
                    fileUpload.click();
                });
            }

            fileUpload.addEventListener('change', function(e) {
                handleFiles(e.target.files, previewContainer);
            });

            uploadArea.addEventListener('dragover', function(e) {
                e.preventDefault();
                uploadArea.classList.add('dragover');
            });

            uploadArea.addEventListener('dragleave', function(e) {
                e.preventDefault();
                uploadArea.classList.remove('dragover');
            });

            uploadArea.addEventListener('drop', function(e) {
                e.preventDefault();
                uploadArea.classList.remove('dragover');
                const files = e.dataTransfer.files;
                handleFiles(files, previewContainer);
            });
        }

        function handleFiles(files, previewContainer) {
            Array.from(files).forEach(file => {
                if (file.type.startsWith('image/')) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        createImagePreview(e.target.result, previewContainer, file);
                    };
                    reader.readAsDataURL(file);
                }
            });
        }

        function createImagePreview(src, container, file) {
            const previewDiv = document.createElement('div');
            previewDiv.className = 'image-preview';
            previewDiv.innerHTML = `
            <img src="${src}" alt="Preview">
            <button type="button" class="btn btn-danger remove-image" style="position: absolute;top: -12px;right: -12px; padding: 1px 5px" onclick="removeImagePreview(this)">×</button>
        `;
            previewDiv.dataset.file = file.name;
            container.appendChild(previewDiv);
        }

        function removeImagePreview(button) {
            button.parentElement.remove();
        }

        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(() => {
                initImageUpload('upload-area', 'file-upload', 'image-preview-container');
                initImageUpload('edit-upload-area', 'edit-file-upload', 'edit-image-preview-container',
                    'edit-file-btn');
            }, 100);
        });

        // Event handlers
        document.addEventListener('click', function(e) {
            if (e.target.closest('.avtar-edit')) {
                e.preventDefault();
                const newsId = e.target.closest('.avtar-edit').getAttribute('data-id');
                editNews(newsId);
            }
        });

        document.addEventListener('click', function(e) {
            if (e.target.closest('.avtar-delete')) {
                e.preventDefault();
                const newsId = e.target.closest('.avtar-delete').getAttribute('data-id');
                const newsTitle = e.target.closest('.avtar-delete').getAttribute('data-title');
                deleteNews(newsId, newsTitle);
            }
        });

        function editNews(id) {
            Swal.fire({
                title: 'Đang tải dữ liệu...',
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });

            fetch(`<?php echo e(route('news.edit', ':id')); ?>`.replace(':id', id))
                .then(response => response.json())
                .then(data => {
                    Swal.close();

                    document.getElementById('edit-title').value = data.title;
                    document.getElementById('edit-description').value = data.description;
                    document.getElementById('edit-category').value = data.category_id;

                    if (editContentEditor) {
                        editContentEditor.setData(data.content || '');
                    } else {
                        initEditEditor().then(() => {
                            if (editContentEditor) {
                                editContentEditor.setData(data.content || '');
                            }
                        });
                    }

                    document.getElementById('edit-news-form').action = `<?php echo e(route('news.update', ':id')); ?>`.replace(':id', id);
                    document.getElementById('edit-image-preview-container').innerHTML = '';

                    if (data.image) {
                        const previewContainer = document.getElementById('edit-image-preview-container');
                        const previewDiv = document.createElement('div');
                        previewDiv.className = 'image-preview';
                        previewDiv.innerHTML = `
                        <img src="${data.image}" alt="Current image">
                        <button type="button" class="btn btn-danger remove-image" style="position: absolute;top: -12px;right: -12px; padding: 1px 5px" onclick="removeImagePreview(this)">×</button>
                    `;
                        previewContainer.appendChild(previewDiv);
                    }

                    const editModal = new bootstrap.Modal(document.getElementById('edit-news'));
                    editModal.show();
                })
                .catch(error => {
                    Swal.close();
                    console.error('Error:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Lỗi!',
                        text: 'Không thể tải dữ liệu tin tức.'
                    });
                });
        }

        function deleteNews(id, title) {
            document.getElementById('delete-news-title').textContent = title;
            document.getElementById('delete-news-form').action = `<?php echo e(route('news.destroy', ':id')); ?>`.replace(':id', id);
            const deleteModal = new bootstrap.Modal(document.getElementById('delete-news'));
            deleteModal.show();
        }

        // Reset form events
        const addNewsModal = document.getElementById('add-news');
        if (addNewsModal) {
            addNewsModal.addEventListener('hidden.bs.modal', function() {
                document.getElementById('add-news-form').reset();
                document.getElementById('image-preview-container').innerHTML = '';
                if (addContentEditor) {
                    addContentEditor.setData('');
                }
            });
        }

        const editNewsModal = document.getElementById('edit-news');
        if (editNewsModal) {
            editNewsModal.addEventListener('hidden.bs.modal', function() {
                document.getElementById('edit-news-form').reset();
                document.getElementById('edit-image-preview-container').innerHTML = '';
                if (editContentEditor) {
                    editContentEditor.setData('');
                    editContentEditor.destroy()
                        .then(() => {
                            editContentEditor = null;
                            // Remove wrapper
                            const wrapper = document.querySelector('#edit-content').closest(
                                '.ckeditor-container');
                            if (wrapper && wrapper.parentElement) {
                                wrapper.parentElement.insertBefore(document.querySelector('#edit-content'),
                                    wrapper);
                                wrapper.remove();
                            }
                        })
                        .catch(error => {
                            console.error('Destroy editor failed:', error);
                        });
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DiLam\blogs\blog\resources\views/admin/news/index.blade.php ENDPATH**/ ?>