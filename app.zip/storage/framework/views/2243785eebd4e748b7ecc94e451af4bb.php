<?php $__env->startSection('content'); ?>
    <div id="ai-news" class="content-section active">
        <div class="section-header">
            <h1>📰 <?php echo e($news?->first()?->category?->name); ?></h1>
            <p>Tin tức về AI, Machine Learning, Deep Learning, Generative AI</p>
        </div>
        <div class="section-content">
            <div class="card-grid">
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card">
                        <h2><a href="<?php echo e(route('news.detail', $it->id)); ?>"><?php echo e($it->title); ?></a></h2>
                        <p><?php echo e($it->description); ?></p>
                        <div class="card-meta">📅 <?php echo e($it->created_at->format('Y-m-d')); ?> | ⏱️ 10 phút đọc</div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DiLam\blogs\C09\resources\views/pages/news/index.blade.php ENDPATH**/ ?>