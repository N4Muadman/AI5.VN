<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Quản lý tiêu chuẩn</a>
                        </li>
                        <li class="breadcrumb-item"><a href="javascript: void(0)">Chi tiết tiêu chuẩn</a>
                        </li>
                    </ul>
                </div>
                <div class="col-md-12">
                    <div class="page-header-title">
                        <h2 class="mb-2">Chi tiết tiêu chuẩn</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-12 col-md-8">
                            <div class="d-flex">
                                <p class="lable-topic">Tên tiêu chuẩn:</p>
                                <span><?php echo e($standards->name); ?></span>
                            </div>

                            <div class="d-flex">
                                <p class="lable-topic">Tên chủ nghiệm</p>
                                <span><?php echo e($standards->project_leader); ?></span>
                            </div>

                            <div class="d-flex">
                                <p class="lable-topic">Các trợ lý</p>
                                <span><?php echo e($standards->assistants); ?></span>
                            </div>

                            <div class="d-flex">
                                <p class="lable-topic">Lĩnh vực</p>
                                <span><?php echo e($standards->area); ?></span>
                            </div>

                            <div class="d-flex">
                                <p class="lable-topic">Thời gian đăng ký</p>
                                <span><?php echo e($standards->registration_period); ?></span>
                            </div>

                            <div class="d-flex">
                                <p class="lable-topic">Thời gian bảo vệ</p>
                                <span><?php echo e($standards->protection_period); ?></span>
                            </div>

                            <div class="d-flex">
                                <p class="lable-topic">Trạng thái</p>
                                <span class="<?php echo e($standards->status == 0 ? 'text-danger' : 'text-success'); ?>"><?php echo e($standards->status_label); ?></span>
                            </div>

                            <div class="d-flex">
                                <p class="lable-topic">Ghi chú</p>
                                <span><?php echo e($standards->note ?? 'Không'); ?></span>
                            </div>

                        </div>
                        <div class="col-12 col-md-4">
                            <div class="d-flex">
                                <img src="<?php echo e($standards->img_project_leader); ?>" alt="" width="100%">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DiLam\C09\resources\views/standards-detail.blade.php ENDPATH**/ ?>