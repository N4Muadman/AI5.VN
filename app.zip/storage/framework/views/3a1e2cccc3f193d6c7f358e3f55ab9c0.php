<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('loginAssets/fonts/icomoon/style.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('loginAssets/css/owl.carousel.min.css')); ?>">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('loginAssets/css/bootstrap.min.css')); ?>">

    <!-- Style -->
    <link rel="stylesheet" href="<?php echo e(asset('loginAssets/css/style.css')); ?>">

    <title>Login</title>
  </head>
  <body>
  <div class="content d-flex align-items-center" style="height: 100vh">
    <div class="container">
      <div class="row">
        <div class="col-md-6 order-md-2">
          <img src="/loginAssets/images/undraw_file_sync_ot38.svg" alt="Image" class="img-fluid">
        </div>
        <div class="col-md-6 contents">
          <div class="row justify-content-center">
            <div class="col-md-8">
              <div class="mb-4">
              <h3>Đăng nhập vào quản trị</h3>
            </div>
            <form action="<?php echo e(route('login')); ?>" method="post">
                <?php echo csrf_field(); ?>
              <div class="form-group first">
                <label for="username">Tên đăng nhập</label>
                <input type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>" id="username">
              </div>
              <div class="form-group last mb-4">
                <label for="password">Mật khẩu</label>
                <input type="password" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> b-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" id="password">
              </div>
              <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p class="text-danger"><?php echo e($message); ?></p>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

              

              <input type="submit" value="Đăng nhập" class="btn text-white btn-block btn-primary">
            </form>
            </div>
          </div>

        </div>

      </div>
    </div>
  </div>


    <script src="<?php echo e(asset('loginAssets/js/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('loginAssets/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('loginAssets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('loginAssets/js/main.js')); ?>"></script>
  </body>
</html>
<?php /**PATH D:\DiLam\blogs\C09\resources\views/auth/login.blade.php ENDPATH**/ ?>