<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Thống kê</a>
                        </li>
                        <li class="breadcrumb-item"><a href="javascript: void(0)">Quản lý đề tài khoa học</a>
                        </li>
                    </ul>
                </div>
                <div class="col-md-12">
                    <div class="page-header-title">
                        <h2 class="mb-2">Danh sách đề tài</h2>
                        <button data-bs-toggle="modal" data-bs-target="#addTopicModal"
                            class="btn btn-light-primary d-flex align-items-center gap-2"><i class="ti ti-plus"></i>Thêm
                            mới đề tài </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <form action="<?php echo e(route('scientificTopics.index')); ?>" method="get">
        <div class="row mt-3">
            <div class="col-6 col-sm-2 mb-2">
                <input type="text" class="form-control" placeholder="Tìm kiếm theo tên đề tài"
                    value="<?php echo e(request('name')); ?>" name="name" id="">
            </div>
            <div class="col-6 col-sm-2 mb-2">
                <input type="text" class="form-control" placeholder="Tìm kiếm theo chủ nhiệm"
                    value="<?php echo e(request('project_leader')); ?>" name="project_leader" id="">
            </div>
            <div class="col-6 col-sm-2 mb-2">
                <input type="text" class="form-control" placeholder="Tìm kiếm theo trợ lý"
                    value="<?php echo e(request('assistants')); ?>" name="assistants" id="">
            </div>
            <div class="col-6 col-sm-2 mb-2">
                <select name="area" class="form-select">
                    <option value="">Tìm kiếm theo lĩnh vực</option>
                    <option value="Khoa học hình sự chung">Khoa học hình sự chung</option>
                    <option value="Dấu vết truyền thống">Dấu vết truyền thống</option>
                    <option value="Dấu vết kỹ thuật số - điện tử, âm thanh">Dấu vết kỹ thuật số - điện tử, âm thanh</option>
                    <option value="Dấu vết hóa – sinh">Dấu vết hóa – sinh</option>
                    <option value="Dấu vết tài liệu">Dấu vết tài liệu</option>
                    <option value="Dấu vết cháy, nổ">Dấu vết cháy, nổ</option>
                    <option value="Dấu vết kỹ thuật">Dấu vết kỹ thuật</option>
                    <option value="Kỹ thuật phòng chống tội phạm">Kỹ thuật phòng chống tội phạm</option>
                    <option value="Pháp y">Pháp y</option>
                </select>
            </div>
            <div class="col-12 d-flex d-sm-block col-sm-3 justify-content-between">
                <button type="submit" class="btn btn-info me-3">Tìm kiếm</button>
            </div>
        </div>
    </form>
    <div class="row">
        <div class="col-12">
            <div class="card table-card">
                <div class="card-body pt-3">
                    <div class="table-responsive">
                        <table class="table table-hover text-center" id="pc-dt-simple">
                            <thead>
                                <tr>
                                    <th>Tên đề tài</th>
                                    <th>Chủ nhiệm</th>
                                    <th></th>
                                    <th>Các trợ lý</th>
                                    <th>Lĩnh vực</th>
                                    <th>Thời gian đăng ký</th>
                                    <th>Thời gian bảo vệ</th>
                                    <th>Trạng thái</th>
                                    <th>Chức năng</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $scientificTopics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><a class="" href="<?php echo e(route('scientificTopics.show', $it->id)); ?>"><h6><?php echo e($it->name); ?></h6></a></td>
                                        <td><?php echo e($it->project_leader); ?></td>
                                        <td><img src="<?php echo e($it->img_project_leader); ?>" alt="ảnh chủ nhiệm" width="50px">
                                        </td>
                                        <td><?php echo e($it->assistants); ?></td>
                                        <td><?php echo e($it->area); ?></td>
                                        <td><?php echo e($it->registration_period); ?></td>
                                        <td><?php echo e($it->protection_period); ?></td>
                                        <td class="<?php echo e($it->status == 0 ? 'text-danger' : 'text-success'); ?>">
                                            <?php echo e($it->status == 0 ? 'Chưa hoàn thành' : 'Đã hoàn thành'); ?></td>
                                        <td>
                                            <a href="#" data-bs-toggle="modal"
                                                data-bs-target="#infoTopicModal-<?php echo e($it->id); ?>"
                                                class="Topic-edit avtar avtar-xs btn-link-secondary"><i
                                                    class="ti ti-info-circle f-18"></i></a>
                                            <a href="#" data-bs-toggle="modal"
                                                data-bs-target="#editTopicModal-<?php echo e($it->id); ?>"
                                                class="Topic-edit avtar avtar-xs btn-link-secondary"><i
                                                    class="ti ti-edit f-18"></i></a>

                                            <a href="#" data-bs-toggle="modal"
                                                class="avtar avtar-xs btn-link-secondary"
                                                data-bs-target="#deleteTopic-<?php echo e($it->id); ?>"><i
                                                    class="ti ti-trash f-18"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="8" class="text-center">Không có đề tài nào</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <div class="ps-5 pe-5">
                            <?php echo e($scientificTopics->links('pagination::bootstrap-5')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Thêm mới -->
    <div class="modal fade" id="addTopicModal" tabindex="-1" aria-labelledby="addTopicModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="addTopicModalLabel">Thêm mới đề tài</h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('scientificTopics.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label class="form-label">Tên đề tài (<span class="text-danger"> * </span>)</label>
                            <input type="text" class="form-control" name="name" placeholder="Nhập tên đề tài"
                                required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Chủ nhiệm đề tài (<span class="text-danger"> * </span>)</label>
                            <input type="text" class="form-control" name="project_leader"
                                placeholder="Nhập chủ nhiệm đề tài" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Ảnh chủ nhiệm (<span class="text-danger"> * </span>)</label>
                            <div class="upload-container">
                                <img alt="Ảnh chủ nhiệm">
                                <input type="file" name="image" accept="image/*">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Các trợ lý (<span class="text-danger"> * </span>)</label>
                            <input type="text" class="form-control" name="assistants"
                                placeholder="Nhập các trợ lý đề tài" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Lĩnh vực (<span class="text-danger"> * </span>)</label>
                            <select name="area" class="form-select">
                                <option value="">chọn lĩnh vực</option>
                                <option value="Khoa học hình sự chung">Khoa học hình sự chung</option>
                                <option value="Dấu vết truyền thống">Dấu vết truyền thống</option>
                                <option value="Dấu vết kỹ thuật số - điện tử, âm thanh">Dấu vết kỹ thuật số - điện tử, âm
                                    thanh</option>
                                <option value="Dấu vết hóa – sinh">Dấu vết hóa – sinh</option>
                                <option value="Dấu vết tài liệu">Dấu vết tài liệu</option>
                                <option value="Dấu vết cháy, nổ">Dấu vết cháy, nổ</option>
                                <option value="Dấu vết kỹ thuật">Dấu vết kỹ thuật</option>
                                <option value="Kỹ thuật phòng chống tội phạm">Kỹ thuật phòng chống tội phạm</option>
                                <option value="Pháp y">Pháp y</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Thời gian đăng ký (<span class="text-danger"> * </span>)</label>
                            <input type="date" class="form-control" name="registration_period" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Thời gian bảo vệ dự kiến (<span class="text-danger"> *
                                </span>)</label>
                            <input type="date" class="form-control" name="protection_period" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Ghi chú </label>
                            <textarea name="notes" cols="30" class="form-control" rows="4" placeholder="Nhập ghi chú"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Thêm mới</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php $__currentLoopData = $scientificTopics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- Modal Xóa -->
        <div class="modal fade" id="deleteTopic-<?php echo e($it->id); ?>" tabindex="-1" aria-labelledby="deleteTopicLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteTopicLabel">Xác nhận đề tài</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p>Bạn có muốn xóa đề tài <strong><?php echo e($it->name); ?></strong> không?</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                        <form action="<?php echo e(route('scientificTopics.destroy', $it->id)); ?>" method="post"
                            style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button type="submit" class="btn btn-danger">Xoá</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="editTopicModal-<?php echo e($it->id); ?>" tabindex="-1"
            aria-labelledby="eidtTopicModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="eidtTopicModalLabel">Chỉnh sửa đề tài</h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('scientificTopics.update', $it->id)); ?>" method="post"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <div class="mb-3">
                                <label class="form-label">Tên đề tài (<span class="text-danger"> * </span>)</label>
                                <input type="text" class="form-control" name="name" placeholder="Nhập ttên đề tài"
                                    required value="<?php echo e($it->name); ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Chủ nhiệm đề tài (<span class="text-danger"> * </span>)</label>
                                <input type="text" class="form-control" placeholder="Nhập chủ nhiệm đề tài"
                                    name="project_leader" required value="<?php echo e($it->project_leader); ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Ảnh chủ nhiệm (<span class="text-danger"> * </span>)</label>
                                <div class="upload-container">
                                    <img src="<?php echo e($it->img_project_leader); ?>" <?php echo $it->img_project_leader ? 'style="display: block"' : ''; ?> alt="Ảnh chủ nhiệm">
                                    <input type="file" name="image" accept="image/*">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Các trợ lý (<span class="text-danger"> * </span>)</label>
                                <input type="text" class="form-control" placeholder="Nhập các trợ lý đề tài"
                                    name="assistants" required value="<?php echo e($it->assistants); ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Lĩnh vực (<span class="text-danger"> * </span>)</label>
                                <select name="area" class="form-select">
                                    <option value="">chọn lĩnh vực</option>
                                    <option value="Khoa học hình sự chung"
                                        <?php echo e($it->area == 'Khoa học hình sự chung' ? 'selected' : ''); ?>>Khoa học hình sự
                                        chung</option>
                                    <option value="Dấu vết truyền thống"
                                        <?php echo e($it->area == 'Dấu vết truyền thống' ? 'selected' : ''); ?>>Dấu vết truyền thống
                                    </option>
                                    <option value="Dấu vết kỹ thuật số - điện tử, âm thanh"
                                        <?php echo e($it->area == 'Dấu vết kỹ thuật số - điện tử, âm thanh' ? 'selected' : ''); ?>>Dấu
                                        vết kỹ thuật số - điện tử, âm thanh</option>
                                    <option value="Dấu vết hóa – sinh"
                                        <?php echo e($it->area == 'Dấu vết hóa – sinh' ? 'selected' : ''); ?>>Dấu vết hóa – sinh
                                    </option>
                                    <option value="Dấu vết tài liệu"
                                        <?php echo e($it->area == 'Dấu vết tài liệu' ? 'selected' : ''); ?>>Dấu vết tài liệu</option>
                                    <option value="Dấu vết cháy, nổ"
                                        <?php echo e($it->area == 'Dấu vết cháy, nổ' ? 'selected' : ''); ?>>Dấu vết cháy, nổ</option>
                                    <option value="Dấu vết kỹ thuật"
                                        <?php echo e($it->area == 'Dấu vết kỹ thuật' ? 'selected' : ''); ?>>Dấu vết kỹ thuật</option>
                                    <option value="Kỹ thuật phòng chống tội phạm"
                                        <?php echo e($it->area == 'Kỹ thuật phòng chống tội phạm' ? 'selected' : ''); ?>>Kỹ thuật phòng
                                        chống tội phạm</option>
                                    <option value="Pháp y" <?php echo e($it->area == 'Pháp y' ? 'selected' : ''); ?>>Pháp y</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Thời gian đăng ký (<span class="text-danger"> * </span>)</label>
                                <input type="date" class="form-control" name="registration_period" required
                                    value="<?php echo e($it->registration_period); ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Thời gian bảo vệ dự kiến (<span class="text-danger"> *
                                    </span>)</label>
                                <input type="date" class="form-control" name="protection_period" required
                                    value="<?php echo e($it->protection_period); ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Ghi chú </label>
                                <textarea name="notes" cols="30" class="form-control" placeholder="Nhập ghi chú" rows="4"><?php echo e($it->notes); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Trạng thái </label>
                                <select name="status" class="form-select">
                                    <option value="0" <?php echo e($it->status == 0 ? 'seleted' : ''); ?> class="text-danger">
                                        Chưa hoàn thành</option>
                                    <option value="1" <?php echo e($it->status == 1 ? 'seleted' : ''); ?> class="text-success">
                                        Đã hoàn thành</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Cập nhật</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <script>
        const uploadContainers = document.querySelectorAll('.upload-container');

        uploadContainers.forEach(container => {
            const fileInput = container.querySelector('input[type="file"]');
            const previewImage = container.querySelector('img');
            const placeholder = container.querySelector('.placeholder');

            fileInput.addEventListener('change', function(event) {
                const file = event.target.files[0];
                if (file) {
                    const reader = new FileReader();

                    reader.onload = function(e) {
                        previewImage.src = e.target.result;
                        previewImage.style.display = 'block';

                        placeholder.style.display = 'none';
                    };

                    reader.readAsDataURL(file);
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DiLam\C09\resources\views/scientific-topic.blade.php ENDPATH**/ ?>