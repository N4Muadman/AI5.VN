<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $__env->yieldContent('title', 'AI Engineer Blog - Machine Learning & Deep Learning'); ?></title>

    <?php echo $__env->yieldContent('meta'); ?>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
        integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.95);
            /* min-height: 100vh; */
            backdrop-filter: blur(10px);
        }

        /* Header */
        header {
            background: linear-gradient(135deg, #2c3e50 0%, #3498db 100%);
            color: white;
            padding: 1rem 0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .header-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 2rem;
        }

        .logo {
            font-size: 1.8rem;
            font-weight: bold;
            background: linear-gradient(45deg, #fff, #74b9ff);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        /* Navigation */
        nav {
            background: #34495e;
            padding: 0;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            align-items: center;
            padding: 0 2rem;
        }

        .nav-menu {
            display: flex;
            list-style: none;
            gap: 0;
        }

        .nav-item {
            position: relative;
        }

        .nav-link {
            color: white;
            text-decoration: none;
            padding: 1rem 1.5rem;
            display: block;
            transition: all 0.3s ease;
            border-bottom: 3px solid transparent;
        }

        .nav-link:hover {
            background: #2c3e50;
            border-bottom: 3px solid #3498db;
            transform: translateY(-2px);
        }

        /* Dropdown */
        .dropdown {
            position: relative;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            background: #2c3e50;
            min-width: 200px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            z-index: 1000;
            border-radius: 0 0 8px 8px;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .dropdown-item {
            color: white;
            padding: 0.8rem 1.5rem;
            text-decoration: none;
            display: block;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }

        .dropdown-item:hover {
            background: #3498db;
            border-left: 3px solid #74b9ff;
            transform: translateX(5px);
        }

        .dropdown-field {
            color: white;
            width: 300px;
            padding: 0.8rem 1.5rem;
            text-decoration: none;
            display: block;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }

        .dropdown-field:hover {
            background: #3498db;
            border-left: 3px solid #74b9ff;
            transform: translateX(5px);
        }

        /* Main Content */
        main {
            padding: 2rem;
        }

        .hero {
            text-align: center;
            padding: 4rem 0;
            background: linear-gradient(135deg, rgba(116, 185, 255, 0.1), rgba(52, 152, 219, 0.1));
            border-radius: 15px;
            margin-bottom: 3rem;
            border: 1px solid rgba(52, 152, 219, 0.2);
        }

        .hero h1 {
            font-size: 3rem;
            margin-bottom: 1rem;
            background: linear-gradient(135deg, #2c3e50, #3498db);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-weight: bold;
        }

        .hero p {
            font-size: 1.2rem;
            color: #555;
            max-width: 600px;
            margin: 0 auto;
            line-height: 1.8;
        }

        /* Content Sections */
        .content-section {
            display: none;
            animation: fadeIn 0.5s ease-in;
        }

        .content-section.active {
            display: block;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .section-header {
            background: linear-gradient(135deg, #3498db, #2c3e50);
            color: white;
            padding: 1.5rem;
            border-radius: 10px 10px 0 0;
            margin-bottom: 0;
        }

        .section-header h2 {
            font-size: 2rem;
            margin-bottom: 0.5rem;
        }

        .section-content {
            background: white;
            padding: 2rem;
            border-radius: 0 0 10px 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 2rem;
        }

        /* Card Grid */
        .card-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 2rem;
            margin-top: 2rem;
        }

        .card {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            border-left: 4px solid #3498db;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        }

        .card h3 {
            color: #2c3e50;
            margin-bottom: 1rem;
            font-size: 1.3rem;
        }

        .card p {
            color: #666;
            line-height: 1.6;
        }

        .card-meta {
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px solid #eee;
            font-size: 0.9rem;
            color: #888;
        }

        /* About Section */
        .about-content {
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 3rem;
            align-items: start;
        }

        .profile-card {
            background: linear-gradient(135deg, #3498db, #2c3e50);
            color: white;
            padding: 2rem;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }

        .profile-img {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            background: linear-gradient(135deg, #74b9ff, #0984e3);
            margin: 0 auto 1rem;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            font-weight: bold;
        }

        .skills {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
            margin-top: 1rem;
        }

        .skill-tag {
            background: rgba(255, 255, 255, 0.2);
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.9rem;
            backdrop-filter: blur(10px);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .nav-container {
                padding: 0 1rem;
            }

            .nav-menu {
                flex-direction: column;
                position: absolute;
                top: 100%;
                left: 0;
                width: 100%;
                background: #34495e;
                display: none;
            }

            .hero h1 {
                font-size: 2rem;
            }

            .about-content {
                grid-template-columns: 1fr;
                gap: 2rem;
            }

            .card-grid {
                grid-template-columns: 1fr;
            }

            main {
                padding: 1rem;
            }
        }

        /* Footer */
        footer {
            background: #2c3e50;
            color: white;
            text-align: center;
            padding: 2rem;
            margin-top: 3rem;
        }

        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
        }

        .social-links {
            margin-top: 1rem;
            display: flex;
            justify-content: center;
            gap: 1rem;
        }

        .social-links a {
            color: white;
            text-decoration: none;
            padding: 0.5rem 1rem;
            background: #3498db;
            border-radius: 5px;
            transition: background 0.3s ease;
        }

        .social-links a:hover {
            background: #74b9ff;
        }
    </style>
</head>

<body>
    <div class="container">
        <header>
            <div class="header-content">
                <div class="logo">Blog AI</div>
                <div class="contact-info">
                    <span>📧 contact@blogai.com | 🌐 Vietnam</span>
                </div>
            </div>
        </header>

        <nav>
            <div class="nav-container">
                <ul class="nav-menu">
                    <li class="nav-item">
                        <a href="/" class="nav-link" onclick="showSection('about')">Giới thiệu</a>
                    </li>
                    <?php if (isset($component)) { $__componentOriginalbf8e71350ffc1f12a4d57372e2005612 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbf8e71350ffc1f12a4d57372e2005612 = $attributes; } ?>
<?php $component = App\View\Components\CategoryBlog::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('category-blog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\CategoryBlog::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbf8e71350ffc1f12a4d57372e2005612)): ?>
<?php $attributes = $__attributesOriginalbf8e71350ffc1f12a4d57372e2005612; ?>
<?php unset($__attributesOriginalbf8e71350ffc1f12a4d57372e2005612); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbf8e71350ffc1f12a4d57372e2005612)): ?>
<?php $component = $__componentOriginalbf8e71350ffc1f12a4d57372e2005612; ?>
<?php unset($__componentOriginalbf8e71350ffc1f12a4d57372e2005612); ?>
<?php endif; ?>
                </ul>
            </div>
        </nav>

        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <footer>
            <div class="footer-content">
                <p>&copy; 2025 AI Engineer Blog. All rights reserved.</p>
                <p>Chia sẻ kiến thức AI/ML cho cộng đồng developer Việt Nam</p>
                <div class="social-links">
                    <a href="#">GitHub</a>
                    <a href="#">LinkedIn</a>
                    <a href="#">Medium</a>
                    <a href="#">Twitter</a>
                </div>
            </div>
        </footer>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>
    <script>
        function showSection(sectionId) {
            // Hide all sections
            const sections = document.querySelectorAll('.content-section');
            sections.forEach(section => {
                section.classList.remove('active');
            });

            // Show selected section
            const selectedSection = document.getElementById(sectionId);
            if (selectedSection) {
                selectedSection.classList.add('active');
            }

            // Scroll to top
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        }

        // Add smooth scrolling and interactive effects
        document.addEventListener('DOMContentLoaded', function() {
            // Add click effects to cards
            const cards = document.querySelectorAll('.card');
            cards.forEach(card => {
                card.addEventListener('click', function() {
                    this.style.transform = 'translateY(-8px) scale(1.02)';
                    setTimeout(() => {
                        this.style.transform = 'translateY(-5px)';
                    }, 150);
                });
            });

            // Add typing effect to hero title
            const heroTitle = document.querySelector('.hero h1');
            if (heroTitle) {
                const text = heroTitle.textContent;
                heroTitle.textContent = '';
                let i = 0;
                const typeWriter = () => {
                    if (i < text.length) {
                        heroTitle.textContent += text.charAt(i);
                        i++;
                        setTimeout(typeWriter, 50);
                    }
                };
                setTimeout(typeWriter, 1000);
            }

            // Add fade-in animation for sections
            const observerOptions = {
                threshold: 0.1,
                rootMargin: '0px 0px -50px 0px'
            };

            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }
                });
            }, observerOptions);

            // Observe all cards
            document.querySelectorAll('.card').forEach(card => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
                observer.observe(card);
            });

            // Add search functionality (placeholder)
            const searchBox = document.createElement('div');
            searchBox.innerHTML = `
                <div style="position: fixed; top: 20px; right: 20px; z-index: 1000;">
                    <input type="text" placeholder="🔍 Tìm kiếm..."
                           style="padding: 10px 15px; border: none; border-radius: 25px;
                                  box-shadow: 0 2px 10px rgba(0,0,0,0.1); width: 200px;
                                  background: white; font-size: 14px;">
                </div>
            `;
            document.body.appendChild(searchBox);

            // Mobile menu toggle
            const createMobileMenu = () => {
                if (window.innerWidth <= 768) {
                    const nav = document.querySelector('.nav-menu');
                    const toggleBtn = document.createElement('button');
                    toggleBtn.innerHTML = '☰';
                    toggleBtn.style.cssText = `
                        background: none; border: none; color: white;
                        font-size: 1.5rem; cursor: pointer; padding: 1rem;
                        display: block;
                    `;

                    toggleBtn.addEventListener('click', () => {
                        nav.style.display = nav.style.display === 'flex' ? 'none' : 'flex';
                    });

                    document.querySelector('.nav-container').prepend(toggleBtn);
                }
            };

            createMobileMenu();
            window.addEventListener('resize', createMobileMenu);

            // Progress indicator
            const progressBar = document.createElement('div');
            progressBar.style.cssText = `
                position: fixed; top: 0; left: 0; width: 0%; height: 3px;
                background: linear-gradient(90deg, #3498db, #74b9ff);
                z-index: 1000; transition: width 0.3s ease;
            `;
            document.body.appendChild(progressBar);

            window.addEventListener('scroll', () => {
                const windowHeight = document.documentElement.scrollHeight - window.innerHeight;
                const scrolled = (window.scrollY / windowHeight) * 100;
                progressBar.style.width = scrolled + '%';
            });

            // Dark mode toggle (bonus feature)
            const darkModeToggle = document.createElement('button');
            darkModeToggle.innerHTML = '🌙';
            darkModeToggle.style.cssText = `
                position: fixed; bottom: 20px; right: 20px; width: 50px; height: 50px;
                border: none; border-radius: 50%; background: #3498db; color: white;
                font-size: 1.2rem; cursor: pointer; box-shadow: 0 2px 10px rgba(0,0,0,0.2);
                z-index: 1000; transition: all 0.3s ease;
            `;

            darkModeToggle.addEventListener('click', () => {
                document.body.classList.toggle('dark-mode');
                darkModeToggle.innerHTML = document.body.classList.contains('dark-mode') ? '☀️' : '🌙';
            });

            document.body.appendChild(darkModeToggle);

            // Add dark mode styles
            const darkModeStyles = document.createElement('style');
            darkModeStyles.textContent = `
                .dark-mode {
                    filter: invert(1) hue-rotate(180deg);
                }
                .dark-mode img, .dark-mode video, .dark-mode iframe {
                    filter: invert(1) hue-rotate(180deg);
                }
            `;
            document.head.appendChild(darkModeStyles);
        });

        // Add particle background effect
        function createParticles() {
            const canvas = document.createElement('canvas');
            canvas.style.cssText = `
                position: fixed; top: 0; left: 0; width: 100%; height: 100%;
                pointer-events: none; z-index: -1; opacity: 0.1;
            `;
            document.body.appendChild(canvas);

            const ctx = canvas.getContext('2d');
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;

            const particles = [];
            for (let i = 0; i < 50; i++) {
                particles.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height,
                    vx: (Math.random() - 0.5) * 0.5,
                    vy: (Math.random() - 0.5) * 0.5,
                    size: Math.random() * 2 + 1
                });
            }

            function animate() {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                ctx.fillStyle = '#3498db';

                particles.forEach(particle => {
                    particle.x += particle.vx;
                    particle.y += particle.vy;

                    if (particle.x < 0 || particle.x > canvas.width) particle.vx *= -1;
                    if (particle.y < 0 || particle.y > canvas.height) particle.vy *= -1;

                    ctx.beginPath();
                    ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
                    ctx.fill();
                });

                requestAnimationFrame(animate);
            }

            animate();

            window.addEventListener('resize', () => {
                canvas.width = window.innerWidth;
                canvas.height = window.innerHeight;
            });
        }

        // Initialize particles after page load
        window.addEventListener('load', createParticles);
    </script>
</body>

</html>
<?php /**PATH D:\DiLam\blogs\blog\resources\views/layout.blade.php ENDPATH**/ ?>