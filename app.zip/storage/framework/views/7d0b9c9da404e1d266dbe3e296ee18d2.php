<?php $__env->startSection('content'); ?>
    <!-- About Section -->
    <div id="about" class="content-section active">
        <div class="hero">
            <h1>Chào mừng đến với Blog AI</h1>
            <p>Khám phá thế giới Machine Learning, Deep Learning và các ứng dụng AI tiên tiến.
                Chia sẻ kiến thức, dự án và những xu hướng mới nhất trong lĩnh vực trí tuệ nhân tạo.</p>
        </div>

        <div class="about-content">
            <div class="profile-card">
                <div class="profile-img">AI</div>
                <h2>AI Engineer</h2>
                <p>Chuyên gia về Machine Learning & Deep Learning</p>
                <div class="skills">
                    <span class="skill-tag">Math</span>
                    <span class="skill-tag">Python</span>
                    <span class="skill-tag">PyTorch</span>
                    <span class="skill-tag">CV</span>
                    <span class="skill-tag">NLP</span>
                    <span class="skill-tag">GenAI</span>
                </div>
            </div>

            <div class="section-content">
                <h3>Về tôi</h3>
                <p>Tôi là một AI Engineer với niềm đam mê nghiên cứu và phát triển các giải pháp AI.
                    Với kinh nghiệm trong việc xây dựng và triển khai các mô hình Machine Learning và Deep
                    Learning,
                    tôi luôn tìm kiếm những cách thức mới để ứng dụng AI vào thực tế.</p>

                <h3>Chuyên môn</h3>
                <ul style="margin-left: 2rem; margin-top: 1rem;">
                    <li><strong>Machine Learning:</strong> Supervised Learning, Unsupervised Learning,
                        Reinforcement Learning</li>
                    <li><strong>Deep Learning:</strong> Neural Networks, CNN, RNN, Transformer</li>
                    <li><strong>Computer Vision:</strong> Image Classification, Object Detection, Segmentation
                    </li>
                    <li><strong>NLP:</strong> Text Processing, Sentiment Analysis, Language Models</li>
                    <li><strong>Generative AI:</strong> GANs, VAEs, Diffusion Models</li>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DiLam\blogs\C09\resources\views/pages/home.blade.php ENDPATH**/ ?>