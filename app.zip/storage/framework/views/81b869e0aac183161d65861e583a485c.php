<?php $__env->startSection('title', $news?->first()?->category?->name); ?> <!-- SEO: dynamic title -->

<?php $__env->startSection('content'); ?>
    <div id="ai-news" class="content-section active">
        <div class="section-header">
            <h1>📰 <?php echo e($news?->first()?->category?->name); ?></h1>
            
        </div>
        <div class="section-content">
            <div class="card-grid">
                <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="card">
                        <h2><a href="<?php echo e(route('news.detail', $it->id)); ?>"><?php echo e($it->title); ?></a></h2>
                        <p><?php echo e($it->description); ?></p>
                        <div class="card-meta">📅 <?php echo e($it->created_at->format('Y-m-d')); ?> | ⏱️ 10 phút đọc</div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-center">Chưa có tin tức nào</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DiLam\blogs\blog\resources\views/pages/news/index.blade.php ENDPATH**/ ?>