<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Quản lý đề tài khoa học</a>
                        </li>
                        <li class="breadcrumb-item"><a href="javascript: void(0)">Chi tiết đề tài</a>
                        </li>
                    </ul>
                </div>
                <div class="col-md-12">
                    <div class="page-header-title">
                        <h2 class="mb-2">Chi tiết đề tài</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-12 col-md-8">
                            <div class="d-flex">
                                <p class="lable-topic">Tên đề tài:</p>
                                <span><?php echo e($topic->name); ?></span>
                            </div>

                            <div class="d-flex">
                                <p class="lable-topic">Tên chủ nghiệm</p>
                                <span><?php echo e($topic->project_leader); ?></span>
                            </div>

                            <div class="d-flex">
                                <p class="lable-topic">Các trợ lý</p>
                                <span><?php echo e($topic->assistants); ?></span>
                            </div>

                            <div class="d-flex">
                                <p class="lable-topic">Lĩnh vực</p>
                                <span><?php echo e($topic->area); ?></span>
                            </div>

                            <div class="d-flex">
                                <p class="lable-topic">Thời gian đăng ký</p>
                                <span><?php echo e($topic->registration_period); ?></span>
                            </div>

                            <div class="d-flex">
                                <p class="lable-topic">Thời gian bảo vệ</p>
                                <span><?php echo e($topic->protection_period); ?></span>
                            </div>

                            <div class="d-flex">
                                <p class="lable-topic">Trạng thái</p>
                                <span class="<?php echo e($topic->status == 0 ? 'text-danger' : 'text-success'); ?>"><?php echo e($topic->status_label); ?></span>
                            </div>

                            <div class="d-flex">
                                <p class="lable-topic">Ghi chú</p>
                                <span><?php echo e($topic->note ?? 'Không'); ?></span>
                            </div>

                        </div>
                        <div class="col-12 col-md-4">
                            <div class="d-flex">
                                <img src="<?php echo e($topic->img_project_leader); ?>" alt="" width="100%">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DiLam\C09\resources\views/topic-detail.blade.php ENDPATH**/ ?>