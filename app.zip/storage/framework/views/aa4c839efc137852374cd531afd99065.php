<?php $__env->startSection('content'); ?>
    <div class="breadcrumb-area section-space--breadcrumb">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 offset-lg-3">
                    <div class="breadcrumb-wrapper text-center">
                        <p class="fs-1 fw-bold">Tin tức</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="page-content-wrapper">
        <div class="blog-page-area">
            <div class="container">
                <div class="news-content">
                    <div class="row" style="width: 99%">
                        <div class="col-12 col-md-8 news-main">
                            <div class="row">
                                <div class="col-12 col-md-8 mb-3">
                                    <div class="news-1">
                                        <?php if(!empty($news_main[0])): ?>
                                            <a href="<?php echo e(route('user.news.detail', $news_main[0]->id)); ?>" class="a-img">
                                                <div class="img-parent mb-3">
                                                    <div class="img"
                                                        style="background-image: url('<?php echo e($news_main[0]->image); ?>')"></div>
                                                </div>
                                            </a>
                                            <a href="<?php echo e(route('user.news.detail', $news_main[0]->id)); ?>"
                                                class="title"><?php echo e($news_main[0]->title); ?></a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-6 col-md-4 mb-3">
                                    <div class="news-2">
                                        <?php if(!empty($news_main[1])): ?>
                                            <a href="<?php echo e(route('user.news.detail', $news_main[1]->id)); ?>" class="a-img">
                                                <div class="img-parent">
                                                    <div class="img"
                                                        style="background-image: url('<?php echo e($news_main[1]->image); ?>')"></div>
                                                </div>
                                            </a>
                                            <div class="p-3">
                                                <a href="<?php echo e(route('user.news.detail', $news_main[1]->id)); ?>"
                                                    class="title"><?php echo e($news_main[1]->title); ?></a>
                                                <div class="d-none d-md-block">
                                                    <p class="short_content"><?php echo e($news_main[1]->description); ?></p>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-6 col-md-4 mb-3">
                                    <div class="news-3">
                                        <?php if(!empty($news_main[2])): ?>
                                            <a href="<?php echo e(route('user.news.detail', $news_main[2]->id)); ?>" class="a-img">
                                                <div class="img-parent mb-3">
                                                    <div class="img"
                                                        style="background-image: url('<?php echo e($news_main[2]->image); ?>')"></div>
                                                </div>
                                            </a>
                                            <a href="<?php echo e(route('user.news.detail', $news_main[2]->id)); ?>"
                                                class="title"><?php echo e($news_main[2]->title); ?></a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-6 col-md-4 mb-3">
                                    <div class="news-4">
                                        <?php if(!empty($news_main[3])): ?>
                                            <a href="<?php echo e(route('user.news.detail', $news_main[3]->id)); ?>" class="a-img">
                                                <div class="img-parent mb-3">
                                                    <div class="img"
                                                        style="background-image: url('<?php echo e($news_main[3]->image); ?>')"></div>
                                                </div>
                                            </a>
                                            <a href="<?php echo e(route('user.news.detail', $news_main[3]->id)); ?>"
                                                class="title"><?php echo e($news_main[3]->title); ?></a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-6 col-md-4 mb-3">
                                    <div class="news-5">
                                        <?php if(!empty($news_main[4])): ?>
                                            <a href="<?php echo e(route('user.news.detail', $news_main[4]->id)); ?>" class="a-img">
                                                <div class="img-parent mb-3">
                                                    <div class="img"
                                                        style="background-image: url('<?php echo e($news_main[4]->image); ?>')"></div>
                                                </div>
                                            </a>
                                            <a href="<?php echo e(route('user.news.detail', $news_main[4]->id)); ?>"
                                                class="title"><?php echo e($news_main[4]->title); ?></a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-4">
                            <div class="header-quick-view">
                                <h2>Xem nhanh</h2>
                                
                            </div>
                            <div class="quick-view">
                                <?php $__empty_1 = true; $__currentLoopData = $quickView; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="quick-view-item">
                                        <a href="<?php echo e(route('user.news.detail', $it->id)); ?>"
                                            class="title"><?php echo e($it->title); ?></a>
                                        <a href="<?php echo e(route('user.news.detail', $it->id)); ?>" class="a-img">
                                            <div class="img-parent">
                                                <div class="img" style="background-image: url('<?php echo e($it->image); ?>')">
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p class="text-white">No news yet</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-3" style="width: 99%">
                        <div class="col-12 col-md-8">
                            <div class="news-list-3">
                                <?php $__empty_1 = true; $__currentLoopData = $news_remaining; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="news-list-item">
                                        <a href="<?php echo e(route('user.news.detail', $it->id)); ?>" class="a-img">
                                            <div class="img-parent">
                                                <div class="img" style="background-image: url('<?php echo e($it->image); ?>')">
                                                </div>
                                            </div>
                                        </a>
                                        <div class="ms-4">
                                            <a href="<?php echo e(route('user.news.detail', $it->id)); ?>"
                                                class="title"><?php echo e($it->title); ?></a>
                                            <p class="short_content mt-2">
                                                <?php echo e($it->description); ?>

                                            </p>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p class="text-white">No news yet</p>
                                <?php endif; ?>

                            </div>
                        </div>
                        <div class="col-12 col-md-4">
                            <div class="news-banner">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DiLam\C09\resources\views/pages/news/index.blade.php ENDPATH**/ ?>