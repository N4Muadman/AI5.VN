<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-12">
                    <div class="page-header-title">
                        <h2 class="mb-2">Thống kê</h2>
                        <?php if(request('start_date') && request('end_date')): ?>
                            <p class="f-18">Thống kê từ ngày: <strong><?php echo e(request('start_date')); ?></strong> đến:
                                <strong><?php echo e(request('end_date')); ?></strong>
                            </p>
                        <?php elseif(request('start_date') && !request('end_date')): ?>
                            <p class="f-18">Thống kê từ ngày: <strong><?php echo e(request('start_date')); ?></strong> đến hết tháng
                                nay</p>
                        <?php elseif(!request('start_date') && request('end_date')): ?>
                            <p class="f-18">Thống kê từ đầu tháng nay đến: <strong><?php echo e(request('end_date')); ?></strong></p>
                        <?php else: ?>
                            <p class="f-18">Thống kê theo <strong>tháng nay</strong></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <form action="<?php echo e(route('dashboard')); ?>" method="get">
        <div class="row">
            <div class="mb-3 col-3">
                <input type="date" class="form-control" title="Ngày bắt đầu" name="start_date"
                    value="<?php echo e(request('start_date')); ?>">
            </div>
            <div class="mb-3 col-3">
                <input type="date" class="form-control" title="Ngày kết thúc" name="end_date"
                    value="<?php echo e(request('end_date')); ?>">
            </div>
            <div class="mb-3 col-3">
                <button type="submit" class="btn btn-info">Tìm kiếm</button>
            </div>
        </div>
    </form>
    <ul class="nav nav-tabs analytics-tab mb-3" id="myTab" role="tablist">
        <li class="nav-item" role="presentation"><button class="nav-link active" id="analytics-tab-1" data-bs-toggle="tab"
                data-bs-target="#analytics-tab-1-pane" type="button" role="tab" aria-controls="analytics-tab-1-pane"
                aria-selected="true">Quản lý đề tài khoa học</button></li>
        <li class="nav-item" role="presentation"><button class="nav-link" id="analytics-tab-2" data-bs-toggle="tab"
                data-bs-target="#analytics-tab-2-pane" type="button" role="tab" aria-controls="analytics-tab-2-pane"
                aria-selected="false" tabindex="-1">Quản lý tiêu chuẩn</button></li>
    </ul>
    <div class="tab-content">
        <div class="tab-pane fade active show" id="analytics-tab-1-pane" role="tabpanel" aria-labelledby="analytics-tab-1">
            <div class="row">
                <div class="col-xxl-6 col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex align-items-center justify-content-between mb-3">
                                <h5 class="mb-0">Thống kê theo trạng thái</h5>
                            </div>
                            <div class="my-3">
                                <div id="deal-rate"></div>
                            </div>
                            <div class="row g-3 text-center">
                                <?php $__currentLoopData = $totalTopicByStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-6 col-lg-6 col-xxl-6">
                                        <div class="overview-product-legends">
                                            <p class="<?php echo e($it->status == 1 ? 'text-success' : 'text-danger'); ?> mb-1">
                                                <span><?php echo e($it->status == 1 ? 'Đã hoàn thành' : 'Chưa hoàn thành'); ?></span>
                                            </p>
                                            <h6 class="mb-0"><?php echo e($it->total); ?></h6>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xxl-6 col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex align-items-center justify-content-between mb-3">
                                <h5 class="mb-0">Thống kê theo lĩnh vực</h5>
                            </div>
                            <div class="my-3">
                                <div id="social-network-rate"></div>
                            </div>
                            <div class="row g-3 text-center">
                                <?php
                                    $textColor = ['#6c757d', '#007bff', '#28a745', '#dc3545', '#ffc107', '#17a2b8'];
                                    $color1 = [];
                                    $color2 = [];
                                ?>
                                <?php $__currentLoopData = $totalTopicByArea; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $indexRamdom = array_rand($textColor);
                                    ?>
                                    <div class="col-4 col-lg-4 col-xxl-4">
                                        <div class="overview-product-legends">
                                            <p class="mb-1" style="color: <?php echo e($textColor[$indexRamdom]); ?>">
                                                <span><?php echo e($it->area); ?></span></p>
                                            <h6 class="mb-0"><?php echo e($it->total); ?></h6>
                                        </div>
                                    </div>
                                    <?php
                                        $color1[] = $textColor[$indexRamdom];
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade" id="analytics-tab-2-pane" role="tabpanel" aria-labelledby="analytics-tab-2" tabindex="0">
            <div class="row">
                <div class="col-xxl-6 col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex align-items-center justify-content-between mb-3">
                                <h5 class="mb-0">Thống kê theo trạng thái</h5>
                            </div>
                            <div class="my-3">
                                <div id="chart3"></div>
                            </div>
                            <div class="row g-3 text-center">
                                <?php $__currentLoopData = $totalStandardByStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-6 col-lg-6 col-xxl-6">
                                        <div class="overview-product-legends">
                                            <p class="<?php echo e($it->status == 1 ? 'text-success' : 'text-danger'); ?> mb-1">
                                                <span><?php echo e($it->status == 1 ? 'Đã hoàn thành' : 'Chưa hoàn thành'); ?></span>
                                            </p>
                                            <h6 class="mb-0"><?php echo e($it->total); ?></h6>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xxl-6 col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex align-items-center justify-content-between mb-3">
                                <h5 class="mb-0">Thống kê theo lĩnh vực</h5>
                            </div>
                            <div class="my-3">
                                <div id="chart4"></div>
                            </div>
                            <div class="row g-3 text-center">
                                <?php $__currentLoopData = $totalStandardByArea; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $indexRamdom = array_rand($textColor);
                                    ?>
                                    <div class="col-4 col-lg-4 col-xxl-4">
                                        <div class="overview-product-legends">
                                            <p class="mb-1" style="color: <?php echo e($textColor[$indexRamdom]); ?>">
                                                <span><?php echo e($it->area); ?></span></p>
                                            <h6 class="mb-0"><?php echo e($it->total); ?></h6>
                                        </div>
                                    </div>
                                    <?php
                                        $color2[] = $textColor[$indexRamdom];
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            function chart1() {
                const totalTopicByStatus = JSON.parse('<?php echo json_encode($totalTopicByStatus); ?>');

                const labels = totalTopicByStatus.map(item => item.status == 0 ? 'Chưa hoàn thành' :
                    'Đã hoàn thành');
                const series = totalTopicByStatus.map(item => item.total);

                new ApexCharts(document.querySelector("#deal-rate"), {
                    chart: {
                        height: 350,
                        type: "pie"
                    },
                    labels: labels,
                    series: series,
                    colors: ['#dc2626', '#2ca87f'],
                    fill: {
                        opacity: [.8, .8]
                    },
                    legend: {
                        show: !1
                    },
                    dataLabels: {
                        enabled: !0,
                        dropShadow: {
                            enabled: !1
                        }
                    },
                    responsive: [{
                        breakpoint: 575,
                        options: {
                            chart: {
                                height: 250
                            },
                            dataLabels: {
                                enabled: !1
                            }
                        }
                    }]
                }).render();
            }

            function chart2() {
                const color = JSON.parse('<?php echo json_encode($color1); ?>');
                const totalTopicByArea = JSON.parse('<?php echo json_encode($totalTopicByArea); ?>');
                const labels = totalTopicByArea.map(item => item.area);
                const series = totalTopicByArea.map(item => item.total);
                new ApexCharts(document.querySelector("#social-network-rate"), {
                    chart: {
                        height: 350,
                        type: "pie"
                    },
                    labels: labels,
                    series: series,
                    colors: color,
                    fill: {
                        opacity: [.8, .8, .8, .8, .8]
                    },
                    legend: {
                        show: !1
                    },
                    dataLabels: {
                        enabled: !0,
                        dropShadow: {
                            enabled: !1
                        }
                    },
                    responsive: [{
                        breakpoint: 575,
                        options: {
                            chart: {
                                height: 250
                            },
                            dataLabels: {
                                enabled: !1
                            }
                        }
                    }]
                }).render();
            }
            function chart3() {
                const totalTopicByStatus = JSON.parse('<?php echo json_encode($totalStandardByStatus); ?>');

                const labels = totalTopicByStatus.map(item => item.status == 0 ? 'Chưa hoàn thành' :
                    'Đã hoàn thành');
                const series = totalTopicByStatus.map(item => item.total);

                new ApexCharts(document.querySelector("#chart3"), {
                    chart: {
                        height: 350,
                        type: "pie"
                    },
                    labels: labels,
                    series: series,
                    colors: ['#dc2626', '#2ca87f'],
                    fill: {
                        opacity: [.8, .8]
                    },
                    legend: {
                        show: !1
                    },
                    dataLabels: {
                        enabled: !0,
                        dropShadow: {
                            enabled: !1
                        }
                    },
                    responsive: [{
                        breakpoint: 575,
                        options: {
                            chart: {
                                height: 250
                            },
                            dataLabels: {
                                enabled: !1
                            }
                        }
                    }]
                }).render();
            }

            function chart4() {
                const color = JSON.parse('<?php echo json_encode($color2); ?>');
                const totalTopicByArea = JSON.parse('<?php echo json_encode($totalStandardByArea); ?>');
                const labels = totalTopicByArea.map(item => item.area);
                const series = totalTopicByArea.map(item => item.total);
                new ApexCharts(document.querySelector("#chart4"), {
                    chart: {
                        height: 350,
                        type: "pie"
                    },
                    labels: labels,
                    series: series,
                    colors: color,
                    fill: {
                        opacity: [.8, .8, .8, .8, .8]
                    },
                    legend: {
                        show: !1
                    },
                    dataLabels: {
                        enabled: !0,
                        dropShadow: {
                            enabled: !1
                        }
                    },
                    responsive: [{
                        breakpoint: 575,
                        options: {
                            chart: {
                                height: 250
                            },
                            dataLabels: {
                                enabled: !1
                            }
                        }
                    }]
                }).render();
            }

            chart1();
            chart2();
            chart3();
            chart4();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DiLam\C09\resources\views/dashboard.blade.php ENDPATH**/ ?>