<?php $__env->startSection('content'); ?>
    <!-- Breadcrumb -->
    <div class="container mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('home')); ?>" style="color: #4A90E2; text-decoration: none;">
                    <i class="fas fa-home me-1"></i>Trang chủ
                </a>
            </li>
            <?php if($news->category): ?>
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('news.category', $news->category->id)); ?>"
                        style="color: #4A90E2; text-decoration: none;">
                        <?php echo e($news->category->name); ?>

                    </a>
                </li>
            <?php endif; ?>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e(Str::limit($news->title, 50)); ?></li>
        </ol>
    </div>

    <!-- Main Content -->
    <div class="mb-5">
        <div class="row">
            <!-- Article Content -->
            <div class="col-lg-8">
                <article class="card shadow-lg border-0" style="border-radius: 15px; overflow: hidden;">
                    <!-- Article Header -->
                    <div class="card-header"
                        style="background: linear-gradient(135deg, #f8f9fa, #e9ecef);
                                                   border-left: 5px solid #4A90E2; padding: 30px;">
                        <h1 class="card-title mb-3"
                            style="color: #2c3e50; font-size: 2rem; font-weight: bold; line-height: 1.3;">
                            <?php echo e($news->title); ?>

                        </h1>

                        <!-- Meta Information -->
                        <div class="d-flex flex-wrap align-items-center mb-3" style="gap: 20px;">
                            <span class="text-muted">
                                <i class="fas fa-calendar-alt me-1"></i>
                                <?php echo e($news->created_at->format('d/m/Y')); ?>

                            </span>
                            <span class="text-muted">
                                <i class="fas fa-clock me-1"></i>
                                <?php echo e($news->created_at->diffForHumans()); ?>

                            </span>
                            <?php if($news->category): ?>
                                <span class="badge rounded-pill" style="background: #4A90E2; font-size: 0.8rem;">
                                    <i class="fas fa-tag me-1"></i><?php echo e($news->category->name); ?>

                                </span>
                            <?php endif; ?>
                            
                        </div>

                        <!-- Description -->
                        <?php if($news->description): ?>
                            <div class="alert"
                                style="background: rgba(74, 144, 226, 0.1); border: 1px solid rgba(74, 144, 226, 0.2);
                                                 border-radius: 10px; padding: 20px;">
                                <p class="mb-0"
                                    style="color: #5a6c7d; font-size: 1.1rem; line-height: 1.6; font-style: italic;">
                                    <?php echo e($news->description); ?>

                                </p>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Featured Image -->
                    <?php if($news->image): ?>
                        <div class="position-relative">
                            <img src="<?php echo e($news->image); ?>" alt="<?php echo e($news->title); ?>" class="img-fluid w-100"
                                style="max-height: 400px; object-fit: cover; ">
                        </div>
                    <?php endif; ?>

                    <!-- Article Body -->
                    <div class="card-body" style="padding: 40px;">
                        <div class="article-content" style="font-size: 1.1rem; line-height: 1.8; color: #5a6c7d;">
                            <?php echo $news->content; ?>

                        </div>

                        <!-- Share Buttons -->
                        <div class="mt-5 pt-4 border-top">
                            <h6 class="mb-3" style="color: #2c3e50;">
                                <i class="fas fa-share-alt me-2"></i>Chia sẻ bài viết:
                            </h6>
                            <div class="d-flex gap-2 flex-wrap">
                                <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode(request()->fullUrl())); ?>"
                                    target="_blank" class="btn btn-primary btn-sm">
                                    <i class="fab fa-facebook-f me-1"></i>Facebook
                                </a>
                                <a href="https://twitter.com/intent/tweet?url=<?php echo e(urlencode(request()->fullUrl())); ?>&text=<?php echo e(urlencode($news->title)); ?>"
                                    target="_blank" class="btn btn-info btn-sm text-white">
                                    <i class="fab fa-twitter me-1"></i>Twitter
                                </a>
                                <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo e(urlencode(request()->fullUrl())); ?>"
                                    target="_blank" class="btn btn-primary btn-sm"
                                    style="background: #0077b5; border-color: #0077b5;">
                                    <i class="fab fa-linkedin-in me-1"></i>LinkedIn
                                </a>
                                <button class="btn btn-secondary btn-sm" onclick="copyLink()">
                                    <i class="fas fa-link me-1"></i>Copy Link
                                </button>
                            </div>
                        </div>
                    </div>
                </article>

                <!-- Navigation to Previous/Next Articles -->
                <div class="row mt-4">
                    <div class="col-md-6">
                        <?php if($prevNews): ?>
                            <div class="card border-0 shadow-sm h-100">
                                <div class="card-body">
                                    <small class="text-muted">
                                        <i class="fas fa-chevron-left me-1"></i>Bài trước
                                    </small>
                                    <h6 class="card-title mt-2">
                                        <a href="<?php echo e(route('news.detail', $prevNews->id)); ?>" class="text-decoration-none"
                                            style="color: #2c3e50;">
                                            <?php echo e(Str::limit($prevNews->title, 80)); ?>

                                        </a>
                                    </h6>
                                    <small class="text-muted"><?php echo e($prevNews->created_at->format('d/m/Y')); ?></small>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <?php if($nextNews): ?>
                            <div class="card border-0 shadow-sm h-100">
                                <div class="card-body text-end">
                                    <small class="text-muted">
                                        Bài tiếp theo<i class="fas fa-chevron-right ms-1"></i>
                                    </small>
                                    <h6 class="card-title mt-2">
                                        <a href="<?php echo e(route('news.detail', $nextNews->id)); ?>" class="text-decoration-none"
                                            style="color: #2c3e50;">
                                            <?php echo e(Str::limit($nextNews->title, 80)); ?>

                                        </a>
                                    </h6>
                                    <small class="text-muted"><?php echo e($nextNews->created_at->format('d/m/Y')); ?></small>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="col-lg-4">
                <!-- Related Articles -->
                <div class="card border-0 shadow-sm mb-4" style="border-radius: 15px;">
                    <div class="card-header" style="background: #4A90E2; color: white; border-radius: 15px 15px 0 0;">
                        <h5 class="mb-0">
                            <i class="fas fa-newspaper me-2"></i>Tin tức liên quan
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php $__empty_1 = true; $__currentLoopData = $relatedNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="d-flex mb-3 pb-3 <?php if(!$loop->last): ?> border-bottom <?php endif; ?>">
                                <?php if($related->image): ?>
                                    <img src="<?php echo e($related->image); ?>" alt="<?php echo e($related->title); ?>" class="rounded me-3"
                                        style="width: 80px; height: 60px; object-fit: cover;">
                                <?php else: ?>
                                    <div class="bg-light rounded me-3 d-flex align-items-center justify-content-center"
                                        style="width: 80px; height: 60px; min-width: 80px;">
                                        <i class="fas fa-image text-muted"></i>
                                    </div>
                                <?php endif; ?>
                                <div class="flex-grow-1">
                                    <h6 class="mb-1">
                                        <a href="<?php echo e(route('news.detail', $related->id)); ?>" class="text-decoration-none"
                                            style="color: #2c3e50; font-size: 0.9rem;">
                                            <?php echo e(Str::limit($related->title, 60)); ?>

                                        </a>
                                    </h6>
                                    <small class="text-muted">
                                        <i class="fas fa-calendar me-1"></i><?php echo e($related->created_at->format('d/m/Y')); ?>

                                    </small>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-muted text-center">Không có tin tức liên quan</p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Categories -->
                <div class="card border-0 shadow-sm mb-4" style="border-radius: 15px;">
                    <div class="card-header" style="background: #4A90E2; color: white; border-radius: 15px 15px 0 0;">
                        <h5 class="mb-0">
                            <i class="fas fa-list me-2"></i>Danh mục
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <a href="<?php echo e(route('news.category', $category->id)); ?>"
                                    class="text-decoration-none <?php if($news->category_id == $category->id): ?> fw-bold <?php endif; ?>"
                                    style="color: #4A90E2;">
                                    <?php echo e($category->name); ?>

                                </a>
                                <span class="badge bg-light text-dark"><?php echo e($category->news_count); ?></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <!-- Back to List Button -->
                <div class="d-grid">
                    <a href="<?php echo e(route('news.index')); ?>" class="btn btn-outline-primary btn-lg">
                        <i class="fas fa-arrow-left me-2"></i>Quay lại danh sách
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script>
        function copyLink() {
            navigator.clipboard.writeText(window.location.href).then(function() {
                alert('Đã sao chép link!');
            });
        }
    </script>

    <style>
        .article-content h1,
        .article-content h2,
        .article-content h3,
        .article-content h4,
        .article-content h5,
        .article-content h6 {
            color: #2c3e50;
            margin-top: 2rem;
            margin-bottom: 1rem;
        }

        .article-content h2 {
            font-size: 1.5rem;
            border-bottom: 2px solid #4A90E2;
            padding-bottom: 0.5rem;
        }

        .article-content p {
            margin-bottom: 1.2rem;
        }

        .article-content ul,
        .article-content ol {
            margin-bottom: 1.2rem;
            padding-left: 1.5rem;
        }

        .article-content li {
            margin-bottom: 0.5rem;
        }

        .breadcrumb {
            background: none;
            padding: 0;
        }

        .breadcrumb-item+.breadcrumb-item::before {
            content: "›";
            color: #6c757d;
        }

        @media (max-width: 768px) {
            .container-fluid {
                padding: 20px 0 !important;
            }

            .card-header {
                padding: 20px !important;
            }

            .card-body {
                padding: 20px !important;
            }

            h1 {
                font-size: 1.5rem !important;
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DiLam\blogs\C09\resources\views/pages/news/detail.blade.php ENDPATH**/ ?>