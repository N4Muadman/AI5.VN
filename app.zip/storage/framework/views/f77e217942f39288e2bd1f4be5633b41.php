<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Thống kê</a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">Quản lý tin tức</li>
                    </ul>
                </div>
                <div class="col-md-12">
                    <div class="page-header-title">
                        <h2 class="mb-2">Danh sách tin tức</h2>
                        <button data-bs-toggle="modal" data-bs-target="#add-news"
                            class="btn btn-light-primary d-flex align-items-center gap-2"><i class="ti ti-plus"></i> Thêm
                            tin tức</button>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <form action="<?php echo e(route('news.index')); ?>" method="get">
        <div class="row align-items-center mb-3">
            <div class="col-12 col-md-3">
                <input type="text" class="form-control" name="title" placeholder="Tìm kiếm theo tiêu đề"
                    value="<?php echo e(request('title')); ?>">
            </div>

            <div class="col-3">
                <button type="submit" class="btn btn-info">Tìm kiếm</button>
            </div>
        </div>
    </form>
    <div class="row">
        <div class="col-12">
            <div class="card table-card">
                <div class="card-body pt-3">
                    <div class="table-responsive">
                        <table class="table table-hover text-center table-fixed" id="pc-dt-simple">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Tiêu đề</th>
                                    <th>Ảnh</th>
                                    <th>Mô tả ngắn</th>
                                    <th>Chức năng</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($it->id); ?></td>
                                        <td><?php echo e($it->title); ?></td>
                                        <td><img src="<?php echo e($it->image); ?>" width="60px" alt=""></td>
                                        <td><?php echo e($it->description); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('user.news.detail', $it->id)); ?>" class="avtar avtar-details avtar-xs btn-link-secondary"
                                                title="XEM CHI TIẾT">
                                                <i class="ti ti-eye f-20"></i>
                                            </a>
                                            <a href="#"class="avtar avtar-edit avtar-xs btn-link-secondary"
                                                data-id="<?php echo e($it->id); ?>" title="CẬP NHẬT">
                                                <i class="ti ti-edit f-20"></i>
                                            </a>
                                            <a href="#" class="avtar avtar-delete avtar-xs btn-link-secondary"
                                                data-title="<?php echo e($it->title); ?>" data-id="<?php echo e($it->id); ?>"
                                                title="XÓA tin tức">
                                                <i class="ti ti-trash f-20"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5">
                                            <p class="text-center">Không có tin tức nào</p>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <div class="ps-5 pe-5">
                            <?php echo e($news->links('pagination::bootstrap-5')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="add-news" tabindex="-1" aria-labelledby="orderModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="orderModalLabel">Thêm mới tin tức</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                                <div class="card-body">
                                    <form action="<?php echo e(route('news.store')); ?>" method="post" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="row g-3">
                                            <div class="col-12">
                                                <div class="mb-3 mb-0">
                                                    <label class="form-label">Tiêu đề</label>
                                                    <input type="text" class="form-control" name="title"
                                                        placeholder="Tiều đề tin tức" required>
                                                </div>
                                            </div>
                                            <div class="col-xl-12">
                                                <div class="border rounded p-3 h-100">
                                                    <div
                                                        class="d-flex flex-column align-items-center justify-content-center mb-2">
                                                        <p class="mb-0 f-16">Ảnh</p>
                                                        <label for="file-upload" class="custom-file-upload">
                                                            <i class="fas fa-upload"></i>
                                                            Thêm ảnh
                                                        </label>
                                                        <input type="file" id="file-upload" name="image"
                                                            style="display: none" accept="image/*" required>
                                                        <div id="file-info" style="margin-top: 10px;"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="mb-3 mb-0"><label class="form-label">Nội dung ngắn</label>
                                                    <textarea class="form-control" name="description" rows="3" placeholder="Nội dung ngắn" required></textarea>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="mb-3 mb-0"><label class="form-label">Nội dung chính</label>
                                                    <textarea class="form-control content" name="content" id="content" rows="3" placeholder="Nội dung chính"></textarea>
                                                </div>
                                            </div>

                                            <div class="col-12">
                                                <div class="row align-items-end justify-content-end g-3">
                                                    <div class="col-sm-auto btn-page">
                                                        <button type="submit" class="btn btn-primary">Thêm mới</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="dialog-delete"></div>
    <div id="dialog-edit"></div>

    <script src="https://cdn.tiny.cloud/1/qf4pnfpic603nbrs0wu0r3cyaadnairp5ngpr08muctqj041/tinymce/7/tinymce.min.js"
        referrerpolicy="origin"></script>
    <script>
        function tiny() {
            tinymce.init({
                selector: '.content',
                advcode_inline: true,
                menubar: false,
                plugins: 'searchreplace autolink directionality visualblocks visualchars image link media codesample table charmap pagebreak nonbreaking anchor insertdatetime advlist lists wordcount help charmap linkchecker emoticons autosave fullscreen',
                toolbar: "undo redo print spellcheckdialog formatpainter | blocks fontfamily fontsize | bold italic underline forecolor backcolor | link image | alignleft aligncenter alignright alignjustify | code",
                height: '450px'
            });
        }

        document.querySelectorAll('.avtar-edit').forEach((element) => {
            element.addEventListener('click', async () => {
                const id = element.dataset.id;

                if (id) {
                    const response = await fetch('<?php echo e(route('news.edit', ':id')); ?>'.replace(
                        ':id', id), {
                        method: "GET",
                        headers: {
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                        }
                    });

                    const data = await response.text();
                    if (!response.ok) {
                        alert('Có lỗi xảy ra', data.message);
                        return;
                    }
                    document.getElementById('dialog-edit').innerHTML = data;
                    await tiny();
                    document.getElementById('file-upload-edit').addEventListener('change', function(event) {
                        var files = event.target.files;
                        var fileInfo = document.getElementById('file-info-edit');

                        if (files.length > 0) {
                            if (files.length === 1) {
                                fileInfo.textContent = "Bạn đã chọn 1 tệp: " + files[0].name;
                            } else {
                                fileInfo.textContent = "Bạn đã chọn " + files.length +
                                    " tệp tin.";
                            }
                        } else {
                            fileInfo.textContent = "Chưa chọn tệp nào.";
                        }
                    });
                    const modal = new bootstrap.Modal(document.getElementById('edit-news'));
                    modal.show();
                }
            })
        })

        document.getElementById('file-upload').addEventListener('change', function(event) {
            var files = event.target.files;
            var fileInfo = document.getElementById('file-info');

            if (files.length > 0) {
                if (files.length === 1) {
                    fileInfo.textContent = "Bạn đã chọn 1 tệp: " + files[0].name;
                } else {
                    fileInfo.textContent = "Bạn đã chọn " + files.length + " tệp tin.";
                }
            } else {
                fileInfo.textContent = "Chưa chọn tệp nào.";
            }
        });
        tiny();

        document.querySelectorAll('.avtar-delete').forEach((element) => {
            element.addEventListener('click', async () => {
                const id = element.dataset.id;
                const title = element.dataset.title;

                if (id) {
                    document.getElementById('dialog-delete').innerHTML = `<div class="modal fade" id="delete-news" tabindex="-1" aria-labelledby="orderModalLabel" aria-hidden="true">
                                                                            <div class="modal-dialog">
                                                                                <div class="modal-content">
                                                                                    <div class="modal-header">
                                                                                        <h5 class="modal-title" id="orderModalLabel">Xác nhận xóa</h5>
                                                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                                    </div>
                                                                                    <div class="modal-body">
                                                                                        <p>Bạn có muốn xóa tin tức: <strong>${title}</strong> không?</p>
                                                                                    </div>
                                                                                    <div class="modal-footer">
                                                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
                                                                                        <form action="<?php echo e(route('news.destroy', ':id')); ?>" method="post">
                                                                                            <?php echo csrf_field(); ?>
                                                                                            <?php echo method_field('delete'); ?>
                                                                                            <button type="submit" class="btn btn-info">Xóa</button>
                                                                                        </form>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>`.replace(':id', id);
                    const modal = new bootstrap.Modal(document.getElementById('delete-news'));
                    modal.show();
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DiLam\C09\resources\views/news/index.blade.php ENDPATH**/ ?>